#pragma once
#include "GameNode.h"

class StartScene : public GameNode
{
	float _alpha;
	float _bgAlpha;

	bool _isAlphaIncrese;

	int _offsetX, _offsetY;
	int _bgSpeed;
	int _count;

public:
	HRESULT init(void); 
	void release(void);
	void update(void);
	void render(void);

	StartScene() {}
	~StartScene() {}

};

