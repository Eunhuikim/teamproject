#include "Stdafx.h"
#include "GameScene.h"
#pragma warning(disable: 4996)

HRESULT SecondScene::init(void)
{
	srand((unsigned)time(NULL));

	IMAGEMANAGER->addImage("������", "Resources/Images/BackGround/background3.bmp", 890, WINSIZE_Y);

	//�ʱ�ȭ
	_bgSpeed = 244;
	_textBufferCnt = _count = _index = _iscardthere = _zombieindex = 0;
	_zombienumber = _playernumber = 0;
	_sun = 1000;
	_card[0].sunneed = 50;
	_card[1].sunneed = 100;
	_card[2].sunneed = 50;

	for (int i = 0; i < PLAYER_MAX; i++)
	{
		sprintf(buf, "�عٶ��%d", i);
		_sunflower[i] = buf;
		sprintf(buf, "ȣ��%d", i);
		_wallnut[i] = buf;
		sprintf(buf, "�⺻�Ĺ�%d", i);
		_shooter[i] = buf;
		_player[i].create = _player[i].enumcreate = false;
		_player[i].time = 0;
	}

	for (int i = 0; i < ZOMBIESTAND_MAX; i++)
	{
		sprintf(buf, "����%d", i);
		_zombiestand[i] = IMAGEMANAGER->addFrameImage(buf, "Resources/Images/Object/zombie.bmp", 226, 69, 5, 1, true, RGB(255, 0, 255));
		_zombiestand[i]->setX(WINSIZE_X - (RND->getFromInTo(40, 200)));
		_zombiestand[i]->setY(WINSIZE_Y - (RND->getFromFloatTo(50, 380)));
		_zombiestand[i]->setFrameY(0);
	}

	for (int i = 0; i < ZOMBIE_MAX; i++)
	{
		sprintf(buf, "�ȴ�����%d", i);
		_zombie[i].cardname = buf;
	}

	//��Ʈ �ʱ�ȭ
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 9; j++)
		{
			_background[i * 9 + j].rc = RectMake(160 + j * 50, 54 + i * 60, 50, 60);
			_background[i * 9 + j].iscardthere = false;
		}

	}
	for (int i = 0; i < 4; i++)
	{
		_cardrc[i] = RectMake(170 + i * 100, 0, 50, 50);
	}

	_zombierandomwidth[0] = _background[0].rc.top;
	_zombierandomwidth[1] = _background[9].rc.top;
	_zombierandomwidth[2] = _background[18].rc.top;
	_zombierandomwidth[3] = _background[27].rc.top;
	_zombierandomwidth[4] = _background[36].rc.top;

	IMAGEMANAGER->addImage("�Ҳ����عٶ��ī��", "Resources/Images/Object/offsunflowercard.bmp", 50, 50, true, RGB(255, 0, 255));
	IMAGEMANAGER->addImage("�عٶ��ī��", "Resources/Images/Object/sunflowercard.bmp", 50, 50, true, RGB(255, 0, 255));
	IMAGEMANAGER->addImage("�Ҳ�������ī��", "Resources/Images/Object/offshootercard.bmp", 50, 50, true, RGB(255, 0, 255));
	IMAGEMANAGER->addImage("����ī��", "Resources/Images/Object/shootercard.bmp", 50, 50, true, RGB(255, 0, 255));
	IMAGEMANAGER->addImage("�Ҳ���ȣ��ī��", "Resources/Images/Object/offwallnutcard.bmp", 50, 50, true, RGB(255, 0, 255));
	IMAGEMANAGER->addImage("ȣ��ī��", "Resources/Images/Object/wallnutcard.bmp", 50, 50, true, RGB(255, 0, 255));

	_zombieimage[0] = IMAGEMANAGER->addFrameImage("�ȴ�����", "Resources/Images/Object/walkzombie.bmp", 180, 68, 4, 1, true, RGB(255, 0, 255));
	_zombieimage[1] = IMAGEMANAGER->addFrameImage("�Դ�����", "Resources/Images/Object/eatzombie.bmp", 432, 68, 9, 1, true, RGB(255, 0, 255));

	_width = _zombierandomwidth[rand() % 4];
	_zombieimage[0]->setFrameY(0);
	_zombieimage[0]->setY(_width);
	_zombieimage[0]->setX(WINSIZE_X);

	return S_OK;
}

void SecondScene::release(void)
{
}


void SecondScene::update(void)
{
	_count++;

	//�����ӿ����̱�
	if (_count % 15 == 0)
	{
		_index--;
		_zombieindex--;
		for (int i = 0; i < PLAYER_MAX; i++)
		{
			if (!_player[i].create) continue;
			if (_index < 0)	_index = _player[i].player->getMaxFrameX();
			_player[i].player->setFrameX(_index);
		}
		for (int i = 0; i < ZOMBIE_MAX; i++)
		{
			if (!_zombie[i].create) continue;
			if (_index < 0)	_index = _zombie[i].zombieimage->getMaxFrameX();
			_zombie[i].zombieimage->setFrameX(_index);
		}

		for (int i = 0; i < ZOMBIESTAND_MAX; i++)
		{
			if (_zombieindex < 0)	_zombieindex = _zombiestand[i]->getMaxFrameX();
			_zombiestand[i]->setFrameX(_zombieindex);
		}
		if (_zombieindex < 0)	_zombieindex = _zombieimage[0]->getMaxFrameX();
		_zombieimage[0]->setFrameX(_zombieindex);
	}

	//�������̱�
	if (_count > 150 && _bgSpeed > 0)
	{
		_bgSpeed -= 2;
		for (int i = 0; i < ZOMBIESTAND_MAX; i++)
		{
			_zombiestand[i]->setX(_zombiestand[i]->getX() + 2);
		}
	}

	//�������
	if (_bgSpeed <= 0 && _count % 1000 == 0)
	{
			zombiecreate(_zombienumber);
	}

	//���� ������
	if (_bgSpeed <= 0 && _count%10 == 0)
	{
		for (int i = 0; i < ZOMBIE_MAX; i++)
		{
			if (!_zombie[i].create) continue;
			_zombie[i].zombieimage->setX(_zombie[i].zombieimage->getX() - 0.1f);
		}
			_zombieimage[0]->setX(_zombieimage[0]->getX() - 0.1f);
	}

	// ���콺 Ŭ�� ��
	if (_mousedown)
	{
		for (int i = 0; i < 4; i++)
		{
			if (_iscardthere) continue;
			if (_card[i].sunneed <= _sun && _cardrc[i].left <= _ptMouse.x && _cardrc[i].right >= _ptMouse.x && _cardrc[i].top <= _ptMouse.y && _cardrc[i].bottom >= _ptMouse.y)
			{
				_iscardthere = true;
				_cardnumber = i;
			}
		}
		for (int i = 0; i < PLAYER_MAX; i++)
		{
			if (!_player[i].sunplayer) continue;
		}
	}

	//ī�� �����̱�
	if (_iscardthere)
	{
		_cardrc[_cardnumber].left = _ptMouse.x - 10;
		_cardrc[_cardnumber].right = _ptMouse.x + 10;
		_cardrc[_cardnumber].top = _ptMouse.y - 10;
		_cardrc[_cardnumber].bottom = _ptMouse.y + 10;
	}

	//���콺 ��ư ���� �� 
	if (!_mousedown)
	{
		for (int i = 0; i < 45; i++)
		{
			if (_background[i].iscardthere == false && _background[i].rc.left <= _cardrc[0].left  &&  _background[i].rc.right >= _cardrc[0].right && _background[i].rc.top <= _cardrc[0].top && _background[i].rc.bottom >= _cardrc[0].bottom)
			{
				playercreate(i, 0);
				_background[i].iscardthere = true;
			}
			if (_background[i].iscardthere == false && _background[i].rc.left <= _cardrc[1].left  &&  _background[i].rc.right >= _cardrc[1].right && _background[i].rc.top <= _cardrc[1].top && _background[i].rc.bottom >= _cardrc[1].bottom)
			{
				playercreate(i, 1);
				_background[i].iscardthere = true;

			}
			if (_background[i].iscardthere == false && _background[i].rc.left <= _cardrc[2].left  &&  _background[i].rc.right >= _cardrc[2].right && _background[i].rc.top <= _cardrc[2].top && _background[i].rc.bottom >= _cardrc[2].bottom)
			{
				playercreate(i, 2);
				_background[i].iscardthere = true;
			}
		}

		_iscardthere = false;
		for (int i = 0; i < 4; i++)
		{
			_cardrc[i] = RectMake(170 + i * 100, 0, 50, 50);
		}
	}

	if (KEYMANAGER->isOnceKeyDown(VK_F4))
	{
		system("pause");
	}
}

void SecondScene::render(void)
{
	//ó������
	IMAGEMANAGER->loopRender("������", getMemDC(), &RectMake(0, 0, 890, WINSIZE_Y), _bgSpeed, 0);
	for (int i = 1; i < ZOMBIESTAND_MAX; i++)
	{
	IMAGEMANAGER->frameRender("����1", getMemDC(), _zombiestand[i]->getX(), _zombiestand[i]->getY());
	}

	//���� ����
	if (_bgSpeed <= 0)
	{
		//ī�� ������
		if (_card[0].sunneed <= _sun) IMAGEMANAGER->render("�عٶ��ī��", getMemDC(), _cardrc[0].left, _cardrc[0].top);
		else IMAGEMANAGER->render("�Ҳ����عٶ��ī��", getMemDC(), _cardrc[0].left, _cardrc[0].top);

		if (_card[1].sunneed <= _sun) IMAGEMANAGER->render("����ī��", getMemDC(), _cardrc[1].left, _cardrc[1].top);
		else IMAGEMANAGER->render("�Ҳ�������ī��", getMemDC(), _cardrc[1].left, _cardrc[1].top);

		if (_card[2].sunneed <= _sun) IMAGEMANAGER->render("ȣ��ī��", getMemDC(), _cardrc[2].left, _cardrc[2].top);
		else IMAGEMANAGER->render("�Ҳ���ȣ��ī��", getMemDC(), _cardrc[2].left, _cardrc[2].top);

		//�Ĺ��� ������
		for (int i = 0; i < PLAYER_MAX; i++)
		{
			if (!_player[i].create) continue;
			IMAGEMANAGER->frameRender(_player[i].cardname, getMemDC(), _player[i].player->getX(), _player[i].player->getY());
		}

		//���� ������
		for (int i = 1; i < ZOMBIE_MAX; i++)
		{
			if (!_zombie[i].create) continue;
			IMAGEMANAGER->frameRender(_zombie[i].cardname, getMemDC(), _zombie[i].zombieimage->getX(), _zombie[i].zombieimage->getY());
		}
		//IMAGEMANAGER->frameRender("�ȴ�����", getMemDC(), _zombieimage[0]->getX(), _zombieimage[0]->getY());
	}


	if (KEYMANAGER->isToggleKey(VK_F1))
	{
		for (int i = 0; i < 45; i++)
		{
			Rectangle(getMemDC(), _background[i].rc.left, _background[i].rc.top, _background[i].rc.right, _background[i].rc.bottom);
		}
		for (int i = 0; i < 4; i++)
		{
			Rectangle(getMemDC(), _cardrc[i].left, _cardrc[i].top, _cardrc[i].right, _cardrc[i].bottom);
		}
	}

	cout << _width <<  endl;
}



// �Ĺ� �����Լ�
void SecondScene::playercreate(int bgnumber, int cardnumber)
{
	//�عٶ�� 
	if (cardnumber == 0)
	{
		_player[bgnumber].create = true;
		_player[bgnumber].player = IMAGEMANAGER->addFrameImage(_sunflower[bgnumber], "Resources/Images/Object/sunflower.bmp", 372, 56, 8, 1, true, RGB(255, 0, 255));
		_player[bgnumber].player->setFrameY(0);
		_player[bgnumber].player->setX(_background[bgnumber].rc.left);
		_player[bgnumber].player->setY(_background[bgnumber].rc.top + 10);
		_player[bgnumber].cardname = _sunflower[bgnumber];
		_sun -= _card[0].sunneed;
		_player[bgnumber].hp = 50;
		_player[bgnumber].sunplayer = true;
		_playernumber++;
	}

	if (cardnumber == 1)
	{
		_player[bgnumber].create = true;
		_player[bgnumber].player = IMAGEMANAGER->addFrameImage(_shooter[bgnumber], "Resources/Images/Object/Peashooter.bmp", 396, 96, 8, 2, true, RGB(255, 0, 255));
		_player[bgnumber].player->setFrameY(0);
		_player[bgnumber].player->setX(_background[bgnumber].rc.left);
		_player[bgnumber].player->setY(_background[bgnumber].rc.top + 10);
		_player[bgnumber].cardname = _shooter[bgnumber];
		_sun -= _card[1].sunneed;
		_player[bgnumber].hp = 50;
		_player[bgnumber].attack = 5;
		_player[bgnumber].attackplayer = true;
		_playernumber++;
	}

	if (cardnumber == 2)
	{
		_player[bgnumber].create = true;
		_player[bgnumber].player = IMAGEMANAGER->addFrameImage(_wallnut[bgnumber], "Resources/Images/Object/wallnut1.bmp", 255, 56, 5, 1, true, RGB(255, 0, 255));
		_player[bgnumber].player->setFrameY(0);
		_player[bgnumber].player->setX(_background[bgnumber].rc.left + 10);
		_player[bgnumber].player->setY(_background[bgnumber].rc.top + 10);
		_player[bgnumber].cardname = _wallnut[bgnumber];
		_sun -= _card[2].sunneed;
		_player[bgnumber].hp = 200;
		_playernumber++;
	}
}

void SecondScene::zombiecreate(int zombienumber)
{
	_zombie[zombienumber].create = true;
	_zombie[zombienumber].zombieimage = IMAGEMANAGER->addFrameImage(_zombie[zombienumber].cardname, "Resources/Images/Object/walkzombie.bmp", 174, 69, 4, 1, true, RGB(255, 0, 255));;
	_zombie[zombienumber].hp = 100;
	_zombie[zombienumber].attack = 1;
	_zombie[zombienumber].zombieimage->setFrameY(0);
	_width = _zombierandomwidth[rand() % 5];
	_zombie[zombienumber].zombieimage->setY(_width);
	_zombie[zombienumber].zombieimage->setX(WINSIZE_X);
	_zombienumber++;
}








