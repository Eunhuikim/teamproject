#include "Stdafx.h"
#include "StartScene.h"

HRESULT StartScene::init(void)
{
	IMAGEMANAGER->addImage("���۷���", "Resources/Images/BackGround/start2.bmp", WINSIZE_X, 764);

	_alpha = _bgAlpha = 0;
	_isAlphaIncrese = false;

	_offsetX = _offsetY = 0;
	_bgSpeed = 0;
	_count = 0;

	return S_OK;
}

void StartScene::release(void)
{

}

void StartScene::update(void)
{
	_count++;
	if (_count >= 100)
	{
		if (_bgSpeed < 382) _bgSpeed++;
	}

}

void StartScene::render(void)
{
	if (_bgSpeed < 382) IMAGEMANAGER->loopRender("���۷���", getMemDC(), &RectMake(0, 0, WINSIZE_X, 764), 0, _bgSpeed);
	if (_bgSpeed == 382) IMAGEMANAGER->loopRender("���۷���", getMemDC(), &RectMake(0, 0, WINSIZE_X, 764), 0, 382);
}
